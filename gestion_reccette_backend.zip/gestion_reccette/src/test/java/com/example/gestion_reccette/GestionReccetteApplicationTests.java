package com.example.gestion_reccette;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionReccetteApplicationTests {

    @Test
    void contextLoads() {
    }

}
