package com.example.gestion_reccette.dao;

import com.example.gestion_reccette.models.RecetteEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository

public interface Recettedao extends JpaRepository<RecetteEntity,Integer> {

    RecetteEntity findByNom(String Nom);
    RecetteEntity save(RecetteEntity recette);
    Optional<RecetteEntity> findById(Integer id);
}



