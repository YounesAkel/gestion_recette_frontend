package com.example.gestion_reccette.controlleur;


import com.example.gestion_reccette.models.RecetteEntity;
import com.example.gestion_reccette.service.Rcetteservice;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/recettes")
public class RecetteController {

    Rcetteservice serv;

    @PostMapping("/recette")
    public RecetteEntity save(@RequestBody RecetteEntity recette){

        return serv.ajouter(recette);
    }
    @GetMapping("/recette")
    public List<RecetteEntity> getClient() {
        return serv.getAllrecettes();
    }
}
