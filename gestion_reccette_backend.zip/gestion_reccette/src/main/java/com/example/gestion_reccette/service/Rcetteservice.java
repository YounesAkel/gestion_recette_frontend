package com.example.gestion_reccette.service;

import com.example.gestion_reccette.dao.Recettedao;
import com.example.gestion_reccette.models.RecetteEntity;

import java.util.List;
import java.util.stream.Collectors;

public class Rcetteservice {

    Recettedao recetterepo;


    public RecetteEntity ajouter(RecetteEntity recette){
        return recetterepo.save(recette);
    }

    public List<RecetteEntity> getAllrecettes() {
        return recetterepo.findAll().stream()
                .collect(Collectors.toList());//cette instruction permet de convertir vers une list
    }
}
