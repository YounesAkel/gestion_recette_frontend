package com.example.gestion_reccette.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="recette")
@Data//cet annotation s'ocupe de la création des getters et setters
@AllArgsConstructor//constructeur avec tous les arguments
@NoArgsConstructor//constructeur par defaut
public class RecetteEntity {

    @Id()
    @GeneratedValue()
    private Integer id;

    @Column(nullable=false)
    private String nom;

    @Column(nullable=false)
    private String ingredients;

    @Column(nullable=false)
    private String etapes_preparation;

    @Column(nullable=false)
    private int duree_preparation;

    @Column()
    private String photo;
}
