package com.example.gestion_reccette;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionReccetteApplication {

    public static void main(String[] args) {
        SpringApplication.run(GestionReccetteApplication.class, args);
    }

}
